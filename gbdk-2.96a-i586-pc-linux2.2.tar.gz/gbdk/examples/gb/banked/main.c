#include "bank.h"

int main(void)
{
    puts("Testing 1,2,3...");
    puts("Calling bank2()");
    bank2(3);
    puts("Back to main()");
    return 0;
}
